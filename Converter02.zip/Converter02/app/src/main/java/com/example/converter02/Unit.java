package com.example.converter02;

import androidx.annotation.NonNull;

public class Unit {

        public Double coefficient;
        public String name;

        //конструктор класса
        public Unit(Double coefficient, String name ) {
            this.coefficient = coefficient;
            this.name = name;
        }


        public String toString() {
            return  name;
        }
}
